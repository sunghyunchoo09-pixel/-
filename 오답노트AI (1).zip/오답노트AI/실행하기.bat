@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
title 오답노트 AI

echo ================================================
echo    오답노트 AI 실행 준비 중...
echo ================================================

rem ---------- 1. Python 확인 (없으면 자동 설치) ----------
call :find_python
if defined PY goto :python_ok
echo [1/4] Python이 없어 자동으로 설치합니다. 몇 분 걸릴 수 있어요...
where winget >nul 2>&1
if errorlevel 1 goto :no_python
winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements
call :find_python
if not defined PY goto :no_python
:python_ok
echo [1/4] Python 확인 완료

rem ---------- 2. 실행 환경 (.venv) ----------
set "VPY=%~dp0.venv\Scripts\python.exe"
if exist "%VPY%" "%VPY%" -c "import sys" >nul 2>&1
if exist "%VPY%" if errorlevel 1 (
    echo       다른 컴퓨터에서 복사된 실행 환경이라 새로 만듭니다...
    rmdir /s /q ".venv"
)
if not exist "%VPY%" (
    echo [2/4] 실행 환경을 만드는 중...
    "%PY%" -m venv .venv
    if errorlevel 1 goto :fail
)
echo [2/4] 실행 환경 확인 완료

rem ---------- 3. 패키지 설치 (requirements.txt 가 바뀌었을 때만) ----------
fc /b requirements.txt ".venv\requirements.stamp" >nul 2>&1
if errorlevel 1 (
    echo [3/4] 필요한 프로그램을 설치하는 중... 처음 한 번만, 1~3분 걸려요
    "%VPY%" -m pip install --disable-pip-version-check -q --upgrade pip
    "%VPY%" -m pip install --disable-pip-version-check -q -r requirements.txt
    if errorlevel 1 goto :fail
    copy /y requirements.txt ".venv\requirements.stamp" >nul
)
echo [3/4] 프로그램 설치 확인 완료

rem ---------- 4. 설정 파일 (없으면 생성) ----------
"%VPY%" scripts\make_secrets.py
if errorlevel 1 goto :fail

echo [4/4] 앱을 실행합니다. 잠시 후 브라우저가 자동으로 열려요.
echo       종료하려면 이 창을 닫으세요.
echo.
"%VPY%" -m streamlit run app.py --browser.gatherUsageStats false
if errorlevel 1 goto :fail
exit /b 0

rem ---------- 함수 ----------
:find_python
set "PY="
for %%C in ("py -3" "python") do if not defined PY (
    for /f "usebackq delims=" %%P in (`%%~C -c "import sys; print(sys.executable) if sys.version_info >= (3, 10) else None" 2^>nul`) do set "PY=%%P"
)
if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
exit /b 0

:no_python
echo.
echo [오류] Python을 자동으로 설치하지 못했습니다.
echo   1. https://www.python.org/downloads/ 에서 Python을 설치하세요.
echo   2. 설치 첫 화면에서 "Add python.exe to PATH" 를 꼭 체크하세요.
echo   3. 설치가 끝나면 이 파일을 다시 실행하세요.
pause
exit /b 1

:fail
echo.
echo [오류] 실행 중 문제가 발생했습니다. 위의 메시지를 확인해 주세요.
echo   인터넷 연결을 확인한 뒤 다시 실행해 보세요.
pause
exit /b 1
