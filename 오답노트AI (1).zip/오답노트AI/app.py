import streamlit as st

from mathnote import auth, db, services, ui_admin, ui_learner
from mathnote.config import retention_days
from mathnote.ui_common import render_auth

st.set_page_config(page_title="오답노트 AI", page_icon="📐", layout="wide")


@st.cache_resource
def bootstrap() -> bool:
    db.init_db()
    auth.ensure_admin()
    return True


@st.cache_data(ttl=3600, show_spinner=False)
def purge_expired_records() -> int:
    """보관 기간이 지난 사진·기록을 한 시간에 한 번 정리한다."""
    return services.purge_expired(retention_days())


bootstrap()
purge_expired_records()

user = st.session_state.get("user")
if user is None:
    render_auth()
elif user["role"] == "admin":
    ui_admin.render(user)
else:
    ui_learner.render(user)
