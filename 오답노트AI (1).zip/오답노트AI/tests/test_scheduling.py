import unittest
from datetime import date

from mathnote.scheduling import ReviewSlot, plan_reviews

D = date(2026, 10, 16)


def _days(slots):
    return [(s.stage, (s.due - D).days, s.adjusted) for s in slots]


class PlanReviewsTest(unittest.TestCase):
    def test_no_exam_uses_1_3_7(self):
        slots, notice = plan_reviews(D, None)
        self.assertEqual(_days(slots), [(1, 1, False), (3, 3, False), (7, 7, False)])
        self.assertIsNone(notice)

    def test_exam_far_away_keeps_default(self):
        slots, notice = plan_reviews(D, date(2026, 10, 24))  # 8일 뒤 → 7일 차가 시험 전날
        self.assertEqual(_days(slots), [(1, 1, False), (3, 3, False), (7, 7, False)])
        self.assertIsNone(notice)

    def test_late_stage_moves_to_exam_eve(self):
        slots, notice = plan_reviews(D, date(2026, 10, 21))  # 5일 뒤 → 전날은 4일 차
        self.assertEqual(_days(slots), [(1, 1, False), (3, 3, False), (7, 4, True)])
        self.assertIn("2026-10-20", notice)

    def test_overlapping_stages_merge(self):
        slots, notice = plan_reviews(D, date(2026, 10, 19))  # 3일 뒤 → 전날은 2일 차
        self.assertEqual(_days(slots), [(1, 1, False), (7, 2, True)])
        self.assertIn("합쳤", notice)

    def test_exam_tomorrow_reviews_today(self):
        slots, notice = plan_reviews(D, date(2026, 10, 17))
        self.assertEqual(slots, [ReviewSlot(7, D, True)])
        self.assertIsNotNone(notice)

    def test_past_exam_falls_back_with_notice(self):
        slots, notice = plan_reviews(D, date(2026, 10, 1))
        self.assertEqual(len(slots), 3)
        self.assertIn("지나", notice)


if __name__ == "__main__":
    unittest.main()
