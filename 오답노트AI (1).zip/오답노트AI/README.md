# 📐 오답노트 AI

고등학생을 위한 AI 수학 오답 분석 및 복습 관리 서비스 (데스크톱 웹)

수학 문제 사진과 내 풀이를 올리면 Google Gemini가 정오답을 판정하고, 오답 원인(개념 / 접근법 / 연산 실수)과 맞춤 학습법을 알려줍니다. 오답 목록에 저장하면 시험일에 맞춰 1·3·7일 차 복습 일정이 자동으로 만들어집니다.

## 실행

### Windows: 한 번 클릭으로 실행

프로젝트 폴더의 **`실행하기.bat`** 을 더블클릭하세요. 새 컴퓨터라도 아래 과정을 자동으로 진행합니다.

1. Python이 없으면 자동 설치 (winget)
2. 실행 환경(`.venv`) 생성과 패키지 설치 (처음 한 번만)
3. 설정 파일이 없으면 Gemini API 키를 묻고, 관리자 임시 비밀번호를 만들어 화면에 표시
4. 앱 실행, 브라우저 자동 열림

### 직접 실행

```bash
pip install -r requirements.txt
cp .streamlit/secrets.toml.example .streamlit/secrets.toml   # 값 채우기
streamlit run app.py
```

| 설정 | 설명 |
|---|---|
| `GEMINI_API_KEY` | Gemini API 키. 없으면 학습자가 사이드바에 직접 입력 |
| `GEMINI_MODEL` | 기본값 `gemini-2.5-flash` |
| `ADMIN_USERNAME` / `ADMIN_PASSWORD` | 관리자 계정. 비밀번호가 있을 때만 생성 |
| `RETENTION_DAYS` | 사진·기록 자동 삭제 기간 (기본 180일) |

`st.secrets` 또는 환경변수로 설정할 수 있습니다. 데이터는 `data/` (SQLite, 업로드 이미지)에 저장됩니다.

## 기능

| 기능 | 화면 |
|---|---|
| 1. 문제 이미지 업로드 (형식·용량 검증, 미리보기, 입력 확인·수정) | 📷 문제 분석 |
| 2. AI 정오답·풀이 분석 (정답 / 오답 / 판단 불가, 실패 사유와 재시도) | 📷 문제 분석 |
| 3. 오답 원인 분류 (근거, 신뢰도, 불확실성 안내, 만족도·오류 신고) | 분석 결과 |
| 4. 맞춤형 학습법, 오답 목록 저장 | 분석 결과 |
| 5. 시험일 기반 1·3·7일 복습 일정, 오늘 / 예정 / 완료 대시보드 | 🏠 복습 대시보드, 📅 시험일 설정 |
| 6. 학습 기록 조회, 관리자 신고 처리 및 서비스 상태 | 📚 오답 노트, 관리자 메뉴 |

## 구조

```
app.py                  진입점 (로그인 → 역할별 화면)
mathnote/
  ai.py                 Gemini 호출, 구조화된 분석 결과 스키마, 오류 분류
  scheduling.py         복습 일정 계산 (시험일 조정)
  db.py                 SQLite 저장소 (학습자 쿼리는 user_id로 범위 제한)
  storage.py            이미지 검증·정규화·저장
  services.py           저장 + 일정 생성 등 유스케이스
  auth.py               회원가입·로그인, 관리자 계정
  ui_common.py / ui_learner.py / ui_admin.py   화면
tests/                  python -m unittest
```
