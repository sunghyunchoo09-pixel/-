"""처음 실행할 때 .streamlit/secrets.toml 을 만든다 (실행하기.bat 에서 호출)."""
import secrets
from pathlib import Path

path = Path(__file__).resolve().parent.parent / ".streamlit" / "secrets.toml"
if path.exists():
    raise SystemExit(0)

password = "Math-" + secrets.token_urlsafe(6)

print()
print("Gemini API 키를 붙여넣고 Enter 를 누르세요.")
print("(없으면 그냥 Enter - 나중에 앱 사이드바에서 입력할 수 있어요)")
try:
    api_key = input("> ").strip().strip('"')
except EOFError:
    api_key = ""

key_line = f'GEMINI_API_KEY = "{api_key}"' if api_key else '# GEMINI_API_KEY = "여기에-키-입력"'
path.parent.mkdir(exist_ok=True)
path.write_text(
    f"""# Gemini API 키 (https://aistudio.google.com/apikey 에서 발급)
{key_line}

# 관리자 계정 - 비밀번호를 바꾸려면 아래 값을 수정하고 앱을 다시 실행하세요
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "{password}"
""",
    encoding="utf-8",
)

print()
print("=" * 48)
print("  관리자 계정이 만들어졌습니다. 꼭 메모해 두세요!")
print("    아이디   : admin")
print(f"    비밀번호 : {password}")
print(f"  (설정 파일: {path})")
print("=" * 48)
print()
