"""업로드 이미지 검증·정규화·저장."""
import io
import uuid
from dataclasses import dataclass
from pathlib import Path

from PIL import Image, ImageOps, UnidentifiedImageError

from .config import ALLOWED_EXTS, MAX_IMAGE_SIDE, MAX_UPLOAD_MB, UPLOAD_DIR

_PIL_FORMATS = {"JPEG", "PNG", "WEBP", "MPO"}  # MPO: 일부 휴대폰 카메라 JPEG


@dataclass
class PreparedImage:
    data: bytes  # 정규화된 JPEG
    mime: str
    original_name: str


class ImageValidationError(ValueError):
    pass


def prepare_upload(name: str, raw: bytes) -> PreparedImage:
    """형식·용량을 검증하고, 회전 보정 및 축소한 JPEG 으로 변환한다."""
    ext = Path(name).suffix.lower().lstrip(".")
    if ext not in ALLOWED_EXTS:
        shown = f".{ext}" if ext else "확장자 없음"
        raise ImageValidationError(
            f"지원하지 않는 파일 형식입니다({shown}). "
            f"{', '.join(e.upper() for e in ALLOWED_EXTS)} 이미지 파일만 업로드할 수 있습니다."
        )
    size_mb = len(raw) / (1024 * 1024)
    if size_mb > MAX_UPLOAD_MB:
        raise ImageValidationError(
            f"파일 용량이 {size_mb:.1f}MB로 최대 {MAX_UPLOAD_MB}MB를 초과합니다. "
            "문제 영역만 잘라내거나 해상도를 낮춰 다시 업로드해 주세요."
        )
    try:
        img = Image.open(io.BytesIO(raw))
        img.load()
    except (UnidentifiedImageError, OSError):
        raise ImageValidationError(
            "이미지 파일을 읽을 수 없습니다. 파일이 손상되었거나 확장자와 실제 형식이 다를 수 있어요."
        ) from None
    if img.format not in _PIL_FORMATS:
        raise ImageValidationError(
            f"파일 확장자는 .{ext}이지만 실제 형식은 {img.format}입니다. JPG, PNG, WEBP 이미지로 저장해 다시 올려 주세요."
        )

    img = ImageOps.exif_transpose(img).convert("RGB")
    img.thumbnail((MAX_IMAGE_SIDE, MAX_IMAGE_SIDE))
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=90)
    return PreparedImage(buf.getvalue(), "image/jpeg", name)


def save_image(user_id: int, data: bytes) -> str:
    """UPLOAD_DIR 기준 상대 경로를 반환한다."""
    rel = Path(str(user_id)) / f"{uuid.uuid4().hex}.jpg"
    path = UPLOAD_DIR / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return rel.as_posix()


def load_image(rel_path: str) -> bytes | None:
    path = UPLOAD_DIR / rel_path
    return path.read_bytes() if path.is_file() else None


def delete_images(rel_paths: list[str]) -> None:
    for rel in rel_paths:
        (UPLOAD_DIR / rel).unlink(missing_ok=True)


def storage_usage_mb() -> float:
    if not UPLOAD_DIR.exists():
        return 0.0
    return sum(p.stat().st_size for p in UPLOAD_DIR.rglob("*") if p.is_file()) / (1024 * 1024)
