"""SQLite 저장소. 학습자용 함수는 모두 user_id 로 범위를 제한해 다른 사용자 기록이 노출되지 않게 한다."""
import json
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timedelta

from .config import DATA_DIR, DB_PATH
from .scheduling import ReviewSlot

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    salt TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('learner', 'admin')),
    exam_date TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS problems (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    image_path TEXT NOT NULL,
    user_answer TEXT NOT NULL,
    verdict TEXT NOT NULL,
    summary TEXT NOT NULL,
    cause_types TEXT NOT NULL DEFAULT '',
    result_json TEXT NOT NULL,
    model TEXT NOT NULL,
    saved INTEGER NOT NULL DEFAULT 0,
    analyzed_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_problems_user ON problems(user_id, analyzed_at);
CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    problem_id INTEGER NOT NULL REFERENCES problems(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    stage INTEGER NOT NULL,
    due_date TEXT NOT NULL,
    adjusted INTEGER NOT NULL DEFAULT 0,
    completed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_reviews_user ON reviews(user_id, due_date);
CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    problem_id INTEGER REFERENCES problems(id) ON DELETE SET NULL,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    rating INTEGER,
    is_report INTEGER NOT NULL DEFAULT 0,
    category TEXT,
    message TEXT,
    status TEXT NOT NULL DEFAULT 'open',
    admin_note TEXT,
    created_at TEXT NOT NULL,
    resolved_at TEXT
);
CREATE TABLE IF NOT EXISTS analysis_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    ok INTEGER NOT NULL,
    error_kind TEXT,
    error_detail TEXT,
    latency_ms INTEGER,
    created_at TEXT NOT NULL
);
"""


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


@contextmanager
def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with connect() as conn:
        conn.executescript(SCHEMA)
        # 이전 버전 DB 마이그레이션
        log_columns = {r["name"] for r in conn.execute("PRAGMA table_info(analysis_logs)")}
        if "error_detail" not in log_columns:
            conn.execute("ALTER TABLE analysis_logs ADD COLUMN error_detail TEXT")


# ---------- 사용자 ----------

def create_user(username: str, password_hash: str, salt: str, role: str = "learner") -> int:
    with connect() as conn:
        cur = conn.execute(
            "INSERT INTO users (username, password_hash, salt, role, created_at) VALUES (?, ?, ?, ?, ?)",
            (username, password_hash, salt, role, _now()),
        )
        return cur.lastrowid


def get_user_by_username(username: str):
    with connect() as conn:
        return conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()


def get_user(user_id: int):
    with connect() as conn:
        return conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()


def update_password(user_id: int, password_hash: str, salt: str) -> None:
    with connect() as conn:
        conn.execute("UPDATE users SET password_hash = ?, salt = ? WHERE id = ?", (password_hash, salt, user_id))


def set_exam_date(user_id: int, exam: date | None) -> None:
    with connect() as conn:
        conn.execute(
            "UPDATE users SET exam_date = ? WHERE id = ?",
            (exam.isoformat() if exam else None, user_id),
        )


# ---------- 문제·분석 결과 ----------

def insert_problem(user_id: int, image_path: str, user_answer: str, result: dict, model: str) -> int:
    causes = ",".join(dict.fromkeys(c["type"] for c in result.get("causes", [])))
    with connect() as conn:
        cur = conn.execute(
            """INSERT INTO problems
               (user_id, image_path, user_answer, verdict, summary, cause_types, result_json, model, analyzed_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                user_id, image_path, user_answer, result["verdict"],
                result.get("problem_summary") or "(문제 요약 없음)", causes,
                json.dumps(result, ensure_ascii=False), model, _now(),
            ),
        )
        return cur.lastrowid


_PROBLEM_LIST_SQL = """
SELECT p.*,
       (SELECT COUNT(*) FROM reviews r WHERE r.problem_id = p.id) AS review_total,
       (SELECT COUNT(*) FROM reviews r WHERE r.problem_id = p.id AND r.completed_at IS NOT NULL) AS review_done
FROM problems p
"""


def get_problem(user_id: int, problem_id: int):
    with connect() as conn:
        return conn.execute(
            _PROBLEM_LIST_SQL + " WHERE p.id = ? AND p.user_id = ?", (problem_id, user_id)
        ).fetchone()


def list_problems(user_id: int, saved_only: bool = False) -> list:
    sql = _PROBLEM_LIST_SQL + " WHERE p.user_id = ?"
    if saved_only:
        sql += " AND p.saved = 1"
    with connect() as conn:
        return conn.execute(sql + " ORDER BY p.analyzed_at DESC", (user_id,)).fetchall()


def mark_saved(user_id: int, problem_id: int) -> None:
    with connect() as conn:
        conn.execute("UPDATE problems SET saved = 1 WHERE id = ? AND user_id = ?", (problem_id, user_id))


def delete_problem(user_id: int, problem_id: int) -> str | None:
    """삭제한 문제의 이미지 경로를 반환한다 (파일 삭제는 호출자가 처리)."""
    with connect() as conn:
        row = conn.execute(
            "SELECT image_path FROM problems WHERE id = ? AND user_id = ?", (problem_id, user_id)
        ).fetchone()
        if row is None:
            return None
        conn.execute("DELETE FROM problems WHERE id = ? AND user_id = ?", (problem_id, user_id))
        return row["image_path"]


def delete_all_problems(user_id: int) -> list[str]:
    with connect() as conn:
        paths = [r["image_path"] for r in conn.execute("SELECT image_path FROM problems WHERE user_id = ?", (user_id,))]
        conn.execute("DELETE FROM problems WHERE user_id = ?", (user_id,))
        return paths


def purge_problems_older_than(days: int) -> list[str]:
    cutoff = (datetime.now() - timedelta(days=days)).isoformat(timespec="seconds")
    with connect() as conn:
        paths = [r["image_path"] for r in conn.execute("SELECT image_path FROM problems WHERE analyzed_at < ?", (cutoff,))]
        conn.execute("DELETE FROM problems WHERE analyzed_at < ?", (cutoff,))
        return paths


# ---------- 복습 일정 ----------

def replace_pending_reviews(user_id: int, problem_id: int, slots: list[ReviewSlot]) -> None:
    """미완료 복습을 새 일정으로 교체한다. 이미 완료한 회차까지는 다시 만들지 않는다."""
    with connect() as conn:
        done = conn.execute(
            "SELECT MAX(stage) FROM reviews WHERE problem_id = ? AND user_id = ? AND completed_at IS NOT NULL",
            (problem_id, user_id),
        ).fetchone()[0] or 0
        conn.execute(
            "DELETE FROM reviews WHERE problem_id = ? AND user_id = ? AND completed_at IS NULL",
            (problem_id, user_id),
        )
        conn.executemany(
            "INSERT INTO reviews (problem_id, user_id, stage, due_date, adjusted) VALUES (?, ?, ?, ?, ?)",
            [(problem_id, user_id, s.stage, s.due.isoformat(), int(s.adjusted)) for s in slots if s.stage > done],
        )


def list_reviews(user_id: int, problem_id: int | None = None) -> list:
    sql = """SELECT r.*, p.summary, p.verdict, p.cause_types
             FROM reviews r JOIN problems p ON p.id = r.problem_id
             WHERE r.user_id = ?"""
    params: list = [user_id]
    if problem_id is not None:
        sql += " AND r.problem_id = ?"
        params.append(problem_id)
    with connect() as conn:
        return conn.execute(sql + " ORDER BY r.due_date, r.stage", params).fetchall()


def complete_review(user_id: int, review_id: int) -> None:
    with connect() as conn:
        conn.execute(
            "UPDATE reviews SET completed_at = ? WHERE id = ? AND user_id = ? AND completed_at IS NULL",
            (_now(), review_id, user_id),
        )


# ---------- 피드백·오류 신고 ----------

def add_feedback(user_id: int, problem_id: int, rating: int | None, is_report: bool,
                 category: str | None, message: str | None) -> None:
    with connect() as conn:
        conn.execute(
            """INSERT INTO feedback (problem_id, user_id, rating, is_report, category, message, status, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (problem_id, user_id, rating, int(is_report), category, message,
             "open" if is_report else "none", _now()),
        )


def list_feedback_for_problem(user_id: int, problem_id: int) -> list:
    with connect() as conn:
        return conn.execute(
            "SELECT * FROM feedback WHERE user_id = ? AND problem_id = ? ORDER BY created_at DESC",
            (user_id, problem_id),
        ).fetchall()


# ---------- 관리자 전용 ----------

def admin_list_feedback(scope: str = "reports", status: str | None = None) -> list:
    """scope: 'reports'(오류 신고) | 'quality'(신고 + 만족도 2점 이하) | 'all'"""
    where = {"reports": "f.is_report = 1",
             "quality": "(f.is_report = 1 OR f.rating <= 2)",
             "all": "1 = 1"}[scope]
    params: list = []
    if status:
        where += " AND f.status = ?"
        params.append(status)
    with connect() as conn:
        return conn.execute(
            f"""SELECT f.*, u.username, p.summary, p.verdict
                FROM feedback f
                LEFT JOIN users u ON u.id = f.user_id
                LEFT JOIN problems p ON p.id = f.problem_id
                WHERE {where} ORDER BY f.created_at DESC""",
            params,
        ).fetchall()


def admin_get_feedback(feedback_id: int):
    with connect() as conn:
        return conn.execute(
            """SELECT f.*, u.username FROM feedback f LEFT JOIN users u ON u.id = f.user_id WHERE f.id = ?""",
            (feedback_id,),
        ).fetchone()


def admin_get_problem(problem_id: int):
    """신고 검토용. 관리자 화면에서만 호출한다."""
    with connect() as conn:
        return conn.execute("SELECT * FROM problems WHERE id = ?", (problem_id,)).fetchone()


def admin_update_report(feedback_id: int, status: str, note: str) -> None:
    with connect() as conn:
        conn.execute(
            "UPDATE feedback SET status = ?, admin_note = ?, resolved_at = ? WHERE id = ?",
            (status, note, _now() if status == "resolved" else None, feedback_id),
        )


def log_analysis(user_id: int, ok: bool, error_kind: str | None, latency_ms: int,
                 error_detail: str | None = None) -> None:
    with connect() as conn:
        conn.execute(
            """INSERT INTO analysis_logs (user_id, ok, error_kind, error_detail, latency_ms, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (user_id, int(ok), error_kind, error_detail, latency_ms, _now()),
        )


def admin_stats() -> dict:
    today = date.today().isoformat()
    since = (datetime.now() - timedelta(hours=24)).isoformat(timespec="seconds")
    with connect() as conn:
        one = lambda sql, *p: conn.execute(sql, p).fetchone()[0]  # noqa: E731
        return {
            "learners": one("SELECT COUNT(*) FROM users WHERE role = 'learner'"),
            "problems": one("SELECT COUNT(*) FROM problems"),
            "saved": one("SELECT COUNT(*) FROM problems WHERE saved = 1"),
            "attempts": one("SELECT COUNT(*) FROM analysis_logs"),
            "successes": one("SELECT COUNT(*) FROM analysis_logs WHERE ok = 1"),
            "attempts_24h": one("SELECT COUNT(*) FROM analysis_logs WHERE created_at >= ?", since),
            "successes_24h": one("SELECT COUNT(*) FROM analysis_logs WHERE ok = 1 AND created_at >= ?", since),
            "avg_latency_ms": one("SELECT AVG(latency_ms) FROM analysis_logs WHERE ok = 1"),
            "avg_rating": one("SELECT AVG(rating) FROM feedback WHERE rating IS NOT NULL"),
            "ratings": one("SELECT COUNT(*) FROM feedback WHERE rating IS NOT NULL"),
            "open_reports": one("SELECT COUNT(*) FROM feedback WHERE is_report = 1 AND status = 'open'"),
            "reviews_due": one("SELECT COUNT(*) FROM reviews WHERE due_date <= ?", today),
            "reviews_done": one("SELECT COUNT(*) FROM reviews WHERE due_date <= ? AND completed_at IS NOT NULL", today),
            "verdicts": dict(conn.execute("SELECT verdict, COUNT(*) FROM problems GROUP BY verdict").fetchall()),
            "cause_rows": [r[0] for r in conn.execute("SELECT cause_types FROM problems WHERE cause_types != ''")],
            "errors_24h": conn.execute(
                """SELECT error_kind, COUNT(*) AS n, MAX(created_at) AS last_at,
                          (SELECT l2.error_detail FROM analysis_logs l2
                           WHERE l2.ok = 0 AND l2.error_kind IS l.error_kind
                           ORDER BY l2.created_at DESC LIMIT 1) AS last_detail
                   FROM analysis_logs l
                   WHERE ok = 0 AND created_at >= ? GROUP BY error_kind ORDER BY n DESC""",
                (since,),
            ).fetchall(),
        }
