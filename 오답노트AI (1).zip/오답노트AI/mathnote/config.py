import os
from pathlib import Path

import streamlit as st

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("MATHNOTE_DATA_DIR", BASE_DIR / "data"))
DB_PATH = DATA_DIR / "app.db"
UPLOAD_DIR = DATA_DIR / "uploads"

# 업로드 정책
ALLOWED_EXTS = ("jpg", "jpeg", "png", "webp")
MAX_UPLOAD_MB = 10
MAX_IMAGE_SIDE = 2048  # AI 전송 전 긴 변 기준 축소 (비용·지연 감소)

# 에빙하우스 망각곡선 기반 복습 회차 (분석 완료일로부터 n일 차)
REVIEW_OFFSETS = (1, 3, 7)

DEFAULT_MODEL = "gemini-2.5-flash"


def get_setting(name: str, default: str | None = None) -> str | None:
    """st.secrets → 환경변수 순으로 설정값을 찾는다."""
    try:
        if name in st.secrets:
            return str(st.secrets[name])
    except Exception:
        pass  # secrets.toml 이 없는 경우
    return os.environ.get(name, default)


def retention_days() -> int:
    return int(get_setting("RETENTION_DAYS", "180"))


def gemini_model() -> str:
    return get_setting("GEMINI_MODEL", DEFAULT_MODEL)
