"""관리자 화면: 대시보드 → 오류 신고 목록 → 신고 상세 / 서비스 상태."""
import json
from collections import Counter

import streamlit as st

from . import db, storage
from .config import DB_PATH, gemini_model, get_setting, retention_days
from .ui_common import CAUSE_LABEL, VERDICT, flash, logout_button, render_analysis, show_flash

DASHBOARD = "📊 관리자 대시보드"
REPORTS = "🚨 오류 신고 목록"
STATUS = "🩺 서비스 상태"
PAGES = [DASHBOARD, REPORTS, STATUS]

ERROR_KIND_LABEL = {
    "timeout": "응답 지연", "network": "네트워크", "auth": "API 키", "quota": "요청 한도",
    "model": "모델 설정", "server": "AI 서버", "request": "요청 거부", "blocked": "안전 정책 차단",
    "empty": "빈 응답", "parse": "응답 형식", "unknown": "기타",
}


def goto(page: str, feedback_id: int | None = None) -> None:
    st.session_state["_admin_nav_pending"] = page
    st.session_state["open_report"] = feedback_id
    st.rerun()


def _clear_open_report() -> None:
    st.session_state["open_report"] = None


def _pct(part: int, whole: int) -> str:
    return f"{part / whole * 100:.0f}%" if whole else "-"


def render(user: dict) -> None:
    if "_admin_nav_pending" in st.session_state:
        st.session_state["admin_nav"] = st.session_state.pop("_admin_nav_pending")
    with st.sidebar:
        st.markdown(f"### 🛠️ 관리자\n**{user['username']}**")
        page = st.radio("메뉴", PAGES, key="admin_nav", label_visibility="collapsed", on_change=_clear_open_report)
        st.divider()
        logout_button()

    show_flash()
    {DASHBOARD: render_dashboard, REPORTS: render_reports, STATUS: render_status}[page]()


def render_dashboard() -> None:
    st.title("📊 관리자 대시보드")
    s = db.admin_stats()

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("학습자", s["learners"])
    c2.metric("분석 완료 문제", s["problems"], f"오답 목록 저장 {s['saved']}", delta_color="off")
    c3.metric("분석 성공률", _pct(s["successes"], s["attempts"]), f"{s['attempts']}회 요청", delta_color="off")
    c4.metric("미처리 오류 신고", s["open_reports"])

    c5, c6, c7, c8 = st.columns(4)
    c5.metric("평균 만족도", f"{s['avg_rating']:.1f} / 5" if s["avg_rating"] else "-", f"{s['ratings']}건", delta_color="off")
    c6.metric("복습 완료율", _pct(s["reviews_done"], s["reviews_due"]), "도래한 복습 기준", delta_color="off")
    c7.metric("평균 분석 시간", f"{s['avg_latency_ms'] / 1000:.1f}초" if s["avg_latency_ms"] else "-")
    c8.metric("최근 24시간 성공률", _pct(s["successes_24h"], s["attempts_24h"]), f"{s['attempts_24h']}회", delta_color="off")

    left, right = st.columns(2)
    with left:
        st.subheader("정오답 분포")
        verdicts = {VERDICT[k][0]: v for k, v in s["verdicts"].items()}
        if verdicts:
            st.bar_chart(verdicts, horizontal=True)
        else:
            st.caption("데이터 없음")
    with right:
        st.subheader("오답 원인 분포")
        causes = Counter(c for row in s["cause_rows"] for c in row.split(","))
        if causes:
            st.bar_chart({CAUSE_LABEL[k]: v for k, v in causes.items()}, horizontal=True)
        else:
            st.caption("데이터 없음")

    st.subheader("최근 미처리 오류 신고")
    reports = db.admin_list_feedback("reports", "open")[:5]
    if not reports:
        st.success("처리할 오류 신고가 없습니다.")
    for f in reports:
        _report_row(f)
    b1, b2 = st.columns(2)
    if b1.button("오류 신고 전체 보기 →", width="stretch"):
        goto(REPORTS)
    if b2.button("서비스 상태 보기 →", width="stretch"):
        goto(STATUS)


def _report_row(f) -> None:
    with st.container(border=True):
        info, action = st.columns([5, 1])
        with info:
            tags = []
            if f["is_report"]:
                tags.append(f"🚨 {f['category']}" + (" · ✅ 처리 완료" if f["status"] == "resolved" else " · ⏳ 검토 대기"))
            if f["rating"]:
                tags.append(f"만족도 {f['rating']}점")
            st.markdown(" · ".join(tags))
            st.caption(f"{f['created_at'][:16].replace('T', ' ')} · {f['username'] or '(탈퇴 사용자)'} · "
                       f"{f['summary'] or '(삭제된 문제)'}")
            if f["message"]:
                st.text(f["message"][:120])
        if action.button("상세", key=f"rep_{f['id']}", width="stretch"):
            goto(REPORTS, f["id"])


def render_reports() -> None:
    if fid := st.session_state.get("open_report"):
        render_report_detail(fid)
        return

    st.title("🚨 오류 신고 목록")
    c1, c2 = st.columns(2)
    scope = c1.radio("범위", ["reports", "quality", "all"], horizontal=True,
                     format_func={"reports": "오류 신고", "quality": "신고 + 낮은 만족도(2점 이하)", "all": "전체 피드백"}.get)
    status = c2.radio("처리 상태", [None, "open", "resolved"], horizontal=True,
                      format_func={None: "전체", "open": "검토 대기", "resolved": "처리 완료"}.get,
                      disabled=scope != "reports")
    rows = db.admin_list_feedback(scope, status if scope == "reports" else None)
    st.caption(f"총 {len(rows)}건")
    if not rows:
        st.info("해당하는 피드백이 없습니다.")
    for f in rows:
        _report_row(f)


def render_report_detail(feedback_id: int) -> None:
    if st.button("← 목록으로"):
        _clear_open_report()
        st.rerun()
    f = db.admin_get_feedback(feedback_id)
    if f is None:
        st.warning("피드백을 찾을 수 없습니다.")
        return

    st.title("신고 상세 확인")
    with st.container(border=True):
        st.markdown(f"**신고자** {f['username'] or '(탈퇴 사용자)'} · **접수** {f['created_at'][:16].replace('T', ' ')}")
        if f["is_report"]:
            st.markdown(f"**오류 유형** {f['category']}")
        if f["rating"]:
            st.markdown(f"**만족도** {'★' * f['rating']} ({f['rating']}점)")
        if f["message"]:
            st.markdown("**내용**")
            st.text(f["message"])

    problem = db.admin_get_problem(f["problem_id"]) if f["problem_id"] else None
    st.subheader("신고된 분석 결과")
    if problem is None:
        st.caption("학습자가 문제를 삭제했거나 보관 기간이 지나 원본을 확인할 수 없습니다.")
    else:
        st.caption(f"모델 {problem['model']} · 분석일 {problem['analyzed_at'][:16].replace('T', ' ')}")
        left, right = st.columns([2, 3])
        with left:
            if image := storage.load_image(problem["image_path"]):
                st.image(image, width="stretch")
            st.markdown("**학습자 풀이·답**")
            with st.container(border=True):
                st.text(problem["user_answer"])
        with right:
            render_analysis(json.loads(problem["result_json"]))

    if not f["is_report"]:
        return
    st.subheader("처리")
    with st.form("resolve_form"):
        status = st.radio("상태", ["open", "resolved"], index=1 if f["status"] == "resolved" else 0, horizontal=True,
                          format_func={"open": "검토 대기", "resolved": "처리 완료"}.get)
        note = st.text_area("학습자에게 보일 답변·처리 메모", value=f["admin_note"] or "", max_chars=1000)
        if st.form_submit_button("저장", type="primary"):
            db.admin_update_report(f["id"], status, note.strip())
            flash("success", "처리 상태를 저장했습니다.")
            st.rerun()


def render_status() -> None:
    st.title("🩺 서비스 상태 현황")
    s = db.admin_stats()

    key_ok = bool(get_setting("GEMINI_API_KEY"))
    c1, c2, c3 = st.columns(3)
    c1.metric("Gemini API 키", "설정됨" if key_ok else "미설정")
    c2.metric("AI 모델", gemini_model())
    c3.metric("최근 24시간 분석 성공률", _pct(s["successes_24h"], s["attempts_24h"]),
              f"{s['attempts_24h']}회 요청", delta_color="off")
    if not key_ok:
        st.warning("서버에 GEMINI_API_KEY가 없어 학습자가 직접 키를 입력해야 합니다. secrets.toml 또는 환경변수에 설정하세요.")

    st.subheader("최근 24시간 분석 실패")
    if not s["errors_24h"]:
        st.success("실패한 분석 요청이 없습니다.")
    else:
        st.dataframe(
            [{"유형": ERROR_KIND_LABEL.get(e["error_kind"], e["error_kind"]), "건수": e["n"],
              "마지막 발생": e["last_at"].replace("T", " "), "최근 오류 내용": e["last_detail"] or ""}
             for e in s["errors_24h"]],
            hide_index=True, width="stretch",
        )

    st.subheader("저장소")
    c4, c5, c6 = st.columns(3)
    c4.metric("DB 크기", f"{DB_PATH.stat().st_size / (1024 * 1024):.2f}MB" if DB_PATH.exists() else "-")
    c5.metric("이미지 저장 용량", f"{storage.storage_usage_mb():.1f}MB")
    c6.metric("기록 보관 기간", f"{retention_days()}일")
