"""여러 저장소 작업을 묶는 유스케이스."""
from datetime import date

from . import db, storage
from .scheduling import plan_reviews


def _analyzed_date(problem) -> date:
    return date.fromisoformat(problem["analyzed_at"][:10])


def save_to_notes(user_id: int, problem, exam: date | None) -> str | None:
    """오답 목록에 저장하고 복습 일정을 만든다. 일정 조정 안내 문구를 반환한다."""
    slots, notice = plan_reviews(_analyzed_date(problem), exam)
    db.mark_saved(user_id, problem["id"])
    db.replace_pending_reviews(user_id, problem["id"], slots)
    return notice


def update_exam_date(user_id: int, exam: date | None) -> int:
    """시험일을 바꾸고 미완료 복습 일정을 다시 계산한다. 일정이 조정된 문제 수를 반환한다."""
    db.set_exam_date(user_id, exam)
    adjusted = 0
    for problem in db.list_problems(user_id, saved_only=True):
        slots, notice = plan_reviews(_analyzed_date(problem), exam)
        db.replace_pending_reviews(user_id, problem["id"], slots)
        adjusted += notice is not None
    return adjusted


def delete_problem(user_id: int, problem_id: int) -> None:
    path = db.delete_problem(user_id, problem_id)
    if path:
        storage.delete_images([path])


def delete_all_records(user_id: int) -> int:
    paths = db.delete_all_problems(user_id)
    storage.delete_images(paths)
    return len(paths)


def purge_expired(days: int) -> int:
    paths = db.purge_problems_older_than(days)
    storage.delete_images(paths)
    return len(paths)
