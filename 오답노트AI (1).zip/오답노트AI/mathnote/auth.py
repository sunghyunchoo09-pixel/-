import hashlib
import hmac
import re
import secrets

from . import db
from .config import get_setting

_ITERATIONS = 200_000
_USERNAME_RE = re.compile(r"^[A-Za-z0-9_가-힣]{2,20}$")


def hash_password(password: str, salt: str | None = None) -> tuple[str, str]:
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), _ITERATIONS)
    return digest.hex(), salt


def _verify(password: str, row) -> bool:
    candidate, _ = hash_password(password, row["salt"])
    return hmac.compare_digest(candidate, row["password_hash"])


def _admin_username() -> str:
    return get_setting("ADMIN_USERNAME", "admin")


def register(username: str, password: str, password2: str) -> str | None:
    """성공 시 None, 실패 시 오류 메시지를 반환한다."""
    username = username.strip()
    if not _USERNAME_RE.match(username):
        return "아이디는 2~20자의 한글, 영문, 숫자, 밑줄(_)만 사용할 수 있습니다."
    if username.lower() == _admin_username().lower():
        return "사용할 수 없는 아이디입니다."
    if len(password) < 8:
        return "비밀번호는 8자 이상이어야 합니다."
    if password != password2:
        return "비밀번호 확인이 일치하지 않습니다."
    if db.get_user_by_username(username):
        return "이미 사용 중인 아이디입니다."
    db.create_user(username, *hash_password(password), role="learner")
    return None


def login(username: str, password: str):
    row = db.get_user_by_username(username.strip())
    if row is None or not _verify(password, row):
        return None
    return row


def ensure_admin() -> None:
    """ADMIN_PASSWORD 가 설정된 경우 관리자 계정을 만들거나 비밀번호를 동기화한다."""
    password = get_setting("ADMIN_PASSWORD")
    if not password:
        return
    username = _admin_username()
    row = db.get_user_by_username(username)
    if row is None:
        db.create_user(username, *hash_password(password), role="admin")
    elif row["role"] == "admin" and not _verify(password, row):
        db.update_password(row["id"], *hash_password(password))
