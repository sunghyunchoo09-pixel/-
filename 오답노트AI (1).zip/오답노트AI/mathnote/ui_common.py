"""학습자·관리자 화면이 함께 쓰는 UI 구성요소."""
import streamlit as st

from . import auth
from .config import ALLOWED_EXTS, MAX_UPLOAD_MB, retention_days

VERDICT = {
    "correct": ("정답", "✅", "green"),
    "incorrect": ("오답", "❌", "red"),
    "undetermined": ("판단 불가", "❔", "orange"),
}
CAUSE_LABEL = {"concept": "개념 오류", "approach": "접근법 오류", "calculation": "단순 연산 실수"}
CAUSE_ICON = {"concept": "📘", "approach": "🧭", "calculation": "🧮"}
CONFIDENCE_LABEL = {"high": ("확실", "green"), "medium": ("추정", "blue"), "low": ("불확실", "orange")}


def verdict_badge(verdict: str) -> None:
    label, icon, color = VERDICT[verdict]
    st.badge(label, icon=icon, color=color)


def cause_text(cause_types: str) -> str:
    return " · ".join(CAUSE_LABEL[c] for c in cause_types.split(",") if c in CAUSE_LABEL)


def flash(kind: str, message: str) -> None:
    """다음 rerun 에서 표시할 메시지를 예약한다."""
    st.session_state["_flash"] = (kind, message)


def show_flash() -> None:
    if item := st.session_state.pop("_flash", None):
        kind, message = item
        getattr(st, kind)(message)


def logout_button() -> None:
    if st.sidebar.button("로그아웃", width="stretch"):
        st.session_state.clear()
        st.rerun()


# ---------- 인증 ----------

def render_auth() -> None:
    st.title("📐 오답노트 AI")
    st.caption("고등학생을 위한 AI 수학 오답 분석 및 복습 관리 서비스")

    _, center, _ = st.columns([1, 2, 1])
    with center:
        login_tab, signup_tab = st.tabs(["로그인", "회원가입"])
        with login_tab, st.form("login_form"):
            username = st.text_input("아이디")
            password = st.text_input("비밀번호", type="password")
            if st.form_submit_button("로그인", type="primary", width="stretch"):
                row = auth.login(username, password)
                if row is None:
                    st.error("아이디 또는 비밀번호가 올바르지 않습니다.")
                else:
                    st.session_state["user"] = {"id": row["id"], "username": row["username"], "role": row["role"]}
                    st.rerun()

        with signup_tab:
            with st.expander("개인정보 및 학습 기록 보관 정책 보기"):
                render_policy_text()
            with st.form("signup_form"):
                username = st.text_input("아이디", help="2~20자 한글·영문·숫자·밑줄")
                password = st.text_input("비밀번호 (8자 이상)", type="password")
                password2 = st.text_input("비밀번호 확인", type="password")
                agreed = st.checkbox("개인정보 및 학습 기록 보관 정책을 확인했습니다.")
                if st.form_submit_button("가입하기", type="primary", width="stretch"):
                    if not agreed:
                        st.error("보관 정책 확인에 동의해 주세요.")
                    elif error := auth.register(username, password, password2):
                        st.error(error)
                    else:
                        st.success("가입이 완료되었습니다. 로그인 탭에서 로그인해 주세요.")


# ---------- 정책 ----------

def render_policy_text() -> None:
    days = retention_days()
    st.markdown(
        f"""
- **저장 항목**: 업로드한 문제 사진, 입력한 풀이·답안, AI 분석 결과, 복습 일정·완료 기록, 만족도·오류 신고
- **이용 목적**: 오답 분석, 오답 노트 및 복습 일정 제공, 분석 품질 개선(오류 신고 검토)
- **AI 처리**: 분석 요청 시 문제 사진과 풀이가 Google Gemini API로 전송됩니다. 사진에 이름·학교 등 개인정보가 보이지 않도록 촬영해 주세요.
- **공개 범위**: 내 학습 기록은 나만 볼 수 있습니다. 관리자는 **오류 신고가 접수된 문제**에 한해 품질 검토 목적으로 열람합니다.
- **보관 기간**: 분석일로부터 **{days}일**이 지나면 사진과 분석 기록이 자동 삭제됩니다.
- **직접 삭제**: 오답 노트에서 개별 문제를, '개인정보·보관 정책' 메뉴에서 전체 기록을 언제든 삭제할 수 있습니다. 삭제된 기록은 복구되지 않습니다.
- **업로드 제한**: {", ".join(e.upper() for e in ALLOWED_EXTS)} 형식, 파일당 최대 {MAX_UPLOAD_MB}MB
"""
    )


# ---------- 분석 결과 ----------

def render_analysis(result: dict) -> None:
    verdict = result["verdict"]
    label, icon, _ = VERDICT[verdict]
    banner = {"correct": st.success, "incorrect": st.error, "undetermined": st.warning}[verdict]
    banner(f"{icon} **{label}** — {result.get('problem_summary', '')}")

    if result.get("math_concepts"):
        st.caption("관련 개념: " + ", ".join(result["math_concepts"]))

    if verdict == "undetermined":
        st.markdown("#### 판단할 수 없는 이유")
        st.markdown(result.get("uncertainty_note") or "문제 또는 풀이를 충분히 인식하지 못했습니다.")
        _render_needs_check(result)
        st.info("문제 전체가 선명하게 보이도록 다시 촬영하거나, 풀이 과정을 더 자세히 입력한 뒤 다시 분석해 보세요.")
        if result.get("correct_answer"):
            with st.expander("AI가 추정한 정답·풀이 방향 (참고용)"):
                _render_solution(result)
        return

    with st.container(border=True):
        _render_solution(result)
    if result.get("solution_feedback"):
        st.markdown("#### 💬 내 풀이 피드백")
        st.markdown(result["solution_feedback"])

    if verdict == "correct":
        if result.get("strengths"):
            st.markdown("#### 👍 풀이의 강점")
            st.markdown("\n".join(f"- {s}" for s in result["strengths"]))
        if result.get("concepts_to_check"):
            st.markdown("#### 🔎 한 번 더 확인할 개념")
            st.markdown("\n".join(f"- {s}" for s in result["concepts_to_check"]))
        return

    st.markdown("#### 🧩 오답 원인 분석")
    for cause in result.get("causes", []):
        conf_label, conf_color = CONFIDENCE_LABEL[cause["confidence"]]
        with st.container(border=True):
            st.markdown(f"**{CAUSE_ICON[cause['type']]} {CAUSE_LABEL[cause['type']]}**")
            st.badge(f"판단 신뢰도: {conf_label}", color=conf_color)
            st.markdown(cause["evidence"])

    uncertain = any(c["confidence"] == "low" for c in result.get("causes", []))
    if uncertain or result.get("uncertainty_note"):
        st.warning(
            "⚠️ **AI가 원인을 확정하기 어려운 부분이 있어요.** "
            + (result.get("uncertainty_note") or "일부 원인은 추정입니다.")
        )
    _render_needs_check(result)
    render_study_advice(result)


def _render_solution(result: dict) -> None:
    st.markdown("**정답**")
    st.markdown(result.get("correct_answer") or "-")
    st.markdown("**올바른 풀이 방향**")
    st.markdown(result.get("solution_direction") or "-")


def _render_needs_check(result: dict) -> None:
    if result.get("needs_check"):
        st.markdown("**추가로 확인이 필요한 부분**")
        st.markdown("\n".join(f"- {s}" for s in result["needs_check"]))


def render_study_advice(result: dict) -> None:
    advice = result.get("study_advice", [])
    if not advice:
        return
    st.markdown("#### 🎯 맞춤형 학습법")
    for item in advice:
        kind = item["cause_type"]
        with st.container(border=True):
            st.markdown(f"**{CAUSE_ICON[kind]} {CAUSE_LABEL[kind]} → {item['focus']}**")
            st.markdown("\n".join(f"{i}. {a}" for i, a in enumerate(item["actions"], 1)))
            st.markdown(f"🔁 **다시 풀 때 확인할 지점:** {item['retry_point']}")
