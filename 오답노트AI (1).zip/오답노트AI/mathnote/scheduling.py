"""에빙하우스 망각곡선 기반 복습 일정 계산 (순수 함수, DB 의존 없음)."""
from dataclasses import dataclass
from datetime import date, timedelta

from .config import REVIEW_OFFSETS


@dataclass(frozen=True)
class ReviewSlot:
    stage: int  # 망각곡선 기준 회차 (1·3·7일 차)
    due: date
    adjusted: bool  # 시험일 때문에 앞당겨졌는지


def plan_reviews(
    analyzed: date, exam: date | None, offsets: tuple[int, ...] = REVIEW_OFFSETS
) -> tuple[list[ReviewSlot], str | None]:
    """분석 완료일 기준 복습 일정을 만든다. 시험일 이후로 넘어가는 회차는 시험 전날로 당긴다.

    반환: (복습 슬롯 목록, 사용자 안내 문구 또는 None)
    """
    default = [ReviewSlot(o, analyzed + timedelta(days=o), False) for o in offsets]
    if exam is None:
        return default, None
    if exam <= analyzed:
        return default, (
            f"등록된 시험일({exam:%Y-%m-%d})이 이미 지나 기본 1·3·7일 일정으로 만들었어요. "
            "다음 시험일을 설정하면 일정이 다시 맞춰집니다."
        )

    last = (exam - analyzed).days - 1  # 시험 전날까지의 일 수
    if last < 1:
        return [ReviewSlot(offsets[-1], analyzed, True)], (
            "시험이 바로 다음 날이라 복습을 분석 당일 1회로 줄였어요."
        )

    # 같은 날로 겹치는 회차는 더 뒤 회차 하나로 합친다
    by_day: dict[int, ReviewSlot] = {}
    for o in offsets:
        day = min(o, last)
        by_day[day] = ReviewSlot(o, analyzed + timedelta(days=day), o > last)
    slots = sorted(by_day.values(), key=lambda s: s.due)

    if not any(s.adjusted for s in slots):
        return slots, None
    notice = (
        f"시험일({exam:%Y-%m-%d}) 이후로 잡히는 복습을 "
        f"시험 전날({exam - timedelta(days=1):%Y-%m-%d})로 앞당겼어요."
    )
    if len(slots) < len(offsets):
        notice += " 겹치는 회차는 하나로 합쳤어요."
    return slots, notice
