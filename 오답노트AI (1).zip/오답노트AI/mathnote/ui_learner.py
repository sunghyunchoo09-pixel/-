"""학습자 화면."""
import json
import time
from datetime import date, timedelta

import streamlit as st

from . import ai, db, services, storage
from .config import MAX_UPLOAD_MB, gemini_model, get_setting
from .ui_common import (
    CAUSE_LABEL, cause_text, flash, logout_button, render_analysis,
    render_policy_text, show_flash, verdict_badge,
)

HOME = "🏠 복습 대시보드"
ANALYZE = "📷 문제 분석"
NOTES = "📚 오답 노트·학습 기록"
EXAM = "📅 시험일 설정"
POLICY = "🔒 개인정보·보관 정책"
PAGES = [HOME, ANALYZE, NOTES, EXAM, POLICY]

REPORT_CATEGORIES = ["정오답 판정 오류", "오답 원인 분류 오류", "문제·풀이 인식 오류", "학습법이 부적절함", "기타"]
RATING_OPTIONS = {5: "매우 정확해요", 4: "대체로 정확해요", 3: "보통이에요", 2: "조금 틀렸어요", 1: "전혀 맞지 않아요"}


def goto(page: str, problem_id: int | None = None) -> None:
    st.session_state["_nav_pending"] = page
    st.session_state["open_problem"] = problem_id
    st.rerun()


def _clear_open_problem() -> None:
    st.session_state["open_problem"] = None


def _api_key() -> str | None:
    return get_setting("GEMINI_API_KEY") or st.session_state.get("api_key_input") or None


def render(user: dict) -> None:
    if "_nav_pending" in st.session_state:
        st.session_state["nav"] = st.session_state.pop("_nav_pending")

    with st.sidebar:
        st.markdown(f"### 📐 오답노트 AI\n**{user['username']}** 님")
        page = st.radio("메뉴", PAGES, key="nav", label_visibility="collapsed", on_change=_clear_open_problem)
        if not get_setting("GEMINI_API_KEY"):
            st.divider()
            st.text_input("Gemini API Key", type="password", key="api_key_input",
                          help="서버에 키가 설정되지 않은 경우에만 필요합니다.")
            st.markdown("[🔑 API Key 발급받기](https://aistudio.google.com/apikey)")
        st.divider()
        logout_button()

    profile = db.get_user(user["id"])
    exam = date.fromisoformat(profile["exam_date"]) if profile["exam_date"] else None

    show_flash()
    {HOME: render_dashboard, ANALYZE: render_analyze, NOTES: render_notes,
     EXAM: render_exam, POLICY: render_policy}[page](user, exam)


# ---------- 대시보드 ----------

def render_dashboard(user: dict, exam: date | None) -> None:
    st.title("🏠 복습 대시보드")
    today = date.today()
    today_iso = today.isoformat()

    reviews = db.list_reviews(user["id"])
    due = [r for r in reviews if not r["completed_at"] and r["due_date"] <= today_iso]
    upcoming = [r for r in reviews if not r["completed_at"] and r["due_date"] > today_iso]
    done = sorted((r for r in reviews if r["completed_at"]), key=lambda r: r["completed_at"], reverse=True)

    c1, c2, c3, c4 = st.columns(4)
    if exam and exam >= today:
        c1.metric("시험까지", "D-Day" if exam == today else f"D-{(exam - today).days}", exam.strftime("%Y-%m-%d"),
                  delta_color="off")
    else:
        c1.metric("시험까지", "미설정")
    c2.metric("오늘 할 복습", len(due))
    c3.metric("예정된 복습", len(upcoming))
    c4.metric("완료한 복습", len(done))

    if not exam or exam < today:
        with st.container(border=True):
            st.markdown("📅 **시험 날짜를 등록하면** 시험 전에 복습이 끝나도록 일정을 맞춰 드려요.")
            if st.button("시험일 설정하기"):
                goto(EXAM)

    if not reviews:
        st.info("아직 복습 일정이 없어요. 문제를 분석하고 **오답 목록에 저장**하면 1일·3일·7일 차 복습이 자동으로 잡힙니다.")
        if st.button("📷 첫 문제 분석하기", type="primary"):
            goto(ANALYZE)
        return

    t1, t2, t3 = st.tabs([f"오늘 할 복습 ({len(due)})", f"예정된 복습 ({len(upcoming)})", f"완료한 복습 ({len(done)})"])
    with t1:
        if not due:
            st.success("오늘 할 복습을 모두 끝냈어요! 🎉")
        for r in due:
            _review_card(user, r, today)
    with t2:
        if not upcoming:
            st.caption("예정된 복습이 없습니다.")
        for r in upcoming:
            _review_card(user, r, today)
    with t3:
        if not done:
            st.caption("아직 완료한 복습이 없습니다.")
        for r in done:
            _review_card(user, r, today)


def _review_card(user: dict, r, today: date, show_open: bool = True) -> None:
    due = date.fromisoformat(r["due_date"])
    with st.container(border=True):
        info, actions = st.columns([4, 2])
        with info:
            st.markdown(f"**{r['stage']}일 차 복습** · {r['summary']}")
            meta = [f"📅 {due:%m월 %d일}"]
            if not r["completed_at"] and due < today:
                meta.append(f"⏰ {(today - due).days}일 지남")
            if r["adjusted"]:
                meta.append("시험 일정에 맞춰 조정됨")
            if causes := cause_text(r["cause_types"]):
                meta.append(causes)
            if r["completed_at"]:
                meta.append(f"✅ {r['completed_at'][:10]} 완료")
            st.caption(" · ".join(meta))
        with actions:
            if show_open and st.button("문제 다시 보기", key=f"open_rv_{r['id']}", width="stretch"):
                goto(NOTES, r["problem_id"])
            if not r["completed_at"]:
                if due <= today:
                    if st.button("✅ 복습 완료", key=f"done_rv_{r['id']}", type="primary", width="stretch"):
                        db.complete_review(user["id"], r["id"])
                        st.toast(f"{r['stage']}일 차 복습 완료!")
                        st.rerun()
                else:
                    st.caption(f"{(due - today).days}일 후 진행")


# ---------- 문제 분석 ----------

def _reset_analyze() -> None:
    for key in ("draft", "analyze_step", "analyzed_problem", "answer_input", "analyze_error"):
        st.session_state.pop(key, None)
    st.session_state["uploader_nonce"] = st.session_state.get("uploader_nonce", 0) + 1


def render_analyze(user: dict, exam: date | None) -> None:
    st.title("📷 문제 분석")
    step = st.session_state.get("analyze_step", "input")
    st.progress({"input": 1, "confirm": 2, "result": 3}[step] / 3,
                text={"input": "1단계 · 문제 사진과 풀이 입력", "confirm": "2단계 · 입력 내용 확인",
                      "result": "3단계 · 분석 결과"}[step])

    if step == "input":
        _analyze_input()
    elif step == "confirm":
        _analyze_confirm(user)
    else:
        problem = db.get_problem(user["id"], st.session_state["analyzed_problem"])
        if problem is None:
            _reset_analyze()
            st.rerun()
        if st.button("➕ 새 문제 분석하기"):
            _reset_analyze()
            st.rerun()
        render_problem(user, problem, exam, key_prefix="new")


def _analyze_input() -> None:
    draft = st.session_state.setdefault("draft", {})
    st.session_state.setdefault("answer_input", draft.get("answer", ""))

    left, right = st.columns(2)
    with left:
        st.subheader("문제 사진")
        uploaded = st.file_uploader(
            f"수학 문제 사진을 올려 주세요 (JPG·PNG·WEBP, 최대 {MAX_UPLOAD_MB}MB)",
            key=f"uploader_{st.session_state.get('uploader_nonce', 0)}",
        )
        if uploaded is not None and uploaded.file_id != draft.get("file_id"):
            try:
                prepared = storage.prepare_upload(uploaded.name, uploaded.getvalue())
            except storage.ImageValidationError as exc:
                draft.pop("image", None)
                st.error(f"⚠️ {exc}")
            else:
                draft.update(image=prepared.data, mime=prepared.mime, name=prepared.original_name,
                             file_id=uploaded.file_id)
        if draft.get("image"):
            st.image(draft["image"], caption=f"미리보기 · {draft['name']}", width="stretch")
            if uploaded is None:
                st.caption("이전에 올린 사진을 사용합니다. 바꾸려면 새 사진을 올려 주세요.")
                if st.button("사진 지우기"):
                    for key in ("image", "mime", "name", "file_id"):
                        draft.pop(key, None)
                    st.rerun()
        st.caption("💡 문제 전체가 잘리지 않고, 글자가 선명하게 보이도록 촬영해 주세요.")

    with right:
        st.subheader("내 풀이 또는 최종 답")
        st.text_area(
            "풀이 과정을 단계별로 적을수록 오답 원인을 정확하게 분석할 수 있어요.",
            key="answer_input", height=260,
            placeholder="예)\n① x² - 4x + 3 = 0 을 인수분해하면 (x-1)(x-3)=0\n② 따라서 x = 1 또는 x = 3\n최종 답: 4",
        )

        if st.button("다음: 입력 내용 확인 →", type="primary", width="stretch"):
            answer = st.session_state["answer_input"].strip()
            problems = []
            if not draft.get("image"):
                problems.append("분석할 **문제 사진**을 업로드해 주세요.")
            if not answer:
                problems.append("**내 풀이 또는 최종 답**을 입력해 주세요. 풀지 못했다면 어디서 막혔는지 적어 주세요.")
            if problems:
                st.warning("분석을 위해 다음 내용을 보완해 주세요.\n\n" + "\n".join(f"- {p}" for p in problems))
            else:
                draft["answer"] = answer
                st.session_state["analyze_step"] = "confirm"
                st.rerun()


def _analyze_confirm(user: dict) -> None:
    draft = st.session_state["draft"]
    left, right = st.columns(2)
    with left:
        st.image(draft["image"], caption=draft["name"], width="stretch")
    with right:
        st.markdown("**입력한 풀이·답**")
        with st.container(border=True):
            st.text(draft["answer"])
        st.caption("내용이 맞는지 확인한 뒤 분석을 요청하세요. 분석 시 사진과 풀이가 Google Gemini로 전송됩니다.")

        b1, b2 = st.columns(2)
        if b1.button("✏️ 수정하기", width="stretch"):
            st.session_state["analyze_step"] = "input"
            st.session_state.pop("analyze_error", None)
            st.rerun()
        retry = "analyze_error" in st.session_state
        if b2.button("🔄 다시 시도" if retry else "🔍 AI 분석 요청", type="primary", width="stretch"):
            _run_analysis(user, draft)

        if err := st.session_state.get("analyze_error"):
            st.error(f"**분석에 실패했습니다.** {err['message']}")
            if err["retryable"]:
                st.info("입력 내용은 그대로 유지됩니다. 잠시 후 **🔄 다시 시도** 버튼을 눌러 주세요.")
            else:
                st.info("이 문제는 다시 시도해도 해결되지 않을 수 있어요. 설정을 확인하거나 관리자에게 문의해 주세요.")
            if err.get("detail"):
                with st.expander("자세한 오류 내용 (문의 시 함께 알려 주세요)"):
                    st.code(err["detail"], language=None, wrap_lines=True)


def _run_analysis(user: dict, draft: dict) -> None:
    api_key = _api_key()
    if not api_key:
        st.session_state["analyze_error"] = {
            "message": "Gemini API 키가 설정되지 않았습니다. 사이드바에 키를 입력하거나 관리자에게 문의해 주세요.",
            "retryable": False,
        }
        st.rerun()

    model = gemini_model()
    started = time.monotonic()
    with st.spinner("AI가 문제를 인식하고 풀이를 분석하고 있어요... (최대 1~2분)"):
        try:
            result, model = ai.analyze(api_key, model, draft["image"], draft["mime"], draft["answer"])
        except ai.AnalysisError as exc:
            db.log_analysis(user["id"], False, exc.kind, int((time.monotonic() - started) * 1000), exc.detail)
            st.session_state["analyze_error"] = {"message": exc.message, "retryable": exc.retryable,
                                                 "detail": exc.detail}
            st.rerun()

    db.log_analysis(user["id"], True, None, int((time.monotonic() - started) * 1000))
    image_path = storage.save_image(user["id"], draft["image"])
    problem_id = db.insert_problem(user["id"], image_path, draft["answer"], result.model_dump(mode="json"), model)
    st.session_state.pop("analyze_error", None)
    st.session_state["analyzed_problem"] = problem_id
    st.session_state["analyze_step"] = "result"
    st.rerun()


# ---------- 문제 상세 (분석 결과 · 저장 · 복습 · 피드백) ----------

def render_problem(user: dict, problem, exam: date | None, key_prefix: str) -> None:
    result = json.loads(problem["result_json"])
    left, right = st.columns([2, 3])
    with left:
        image = storage.load_image(problem["image_path"])
        if image:
            st.image(image, width="stretch")
        else:
            st.caption("이미지를 찾을 수 없습니다.")
        st.markdown("**내 풀이·답**")
        with st.container(border=True):
            st.text(problem["user_answer"])
        st.caption(f"분석일 {problem['analyzed_at'][:16].replace('T', ' ')}")
    with right:
        render_analysis(result)

    st.divider()
    save_col, feedback_col = st.columns(2)
    with save_col:
        _render_save_and_reviews(user, problem, exam, key_prefix)
    with feedback_col:
        _render_feedback(user, problem, key_prefix)


def _render_save_and_reviews(user: dict, problem, exam: date | None, key_prefix: str) -> None:
    st.subheader("📌 오답 목록 · 복습 일정")
    if not problem["saved"]:
        hint = "오답 목록에 저장하면" if problem["verdict"] == "incorrect" else "다시 보고 싶은 문제라면 저장해 두세요. 저장하면"
        st.markdown(f"{hint} 오늘을 기준으로 **1일·3일·7일 차 복습 일정**이 자동으로 만들어져요.")
        if not exam:
            st.caption("시험일이 없으면 기본 일정으로 만들고, 나중에 시험일을 등록하면 자동으로 다시 맞춰요.")
        if st.button("오답 목록에 저장하고 복습 일정 만들기", key=f"{key_prefix}_save", type="primary"):
            notice = services.save_to_notes(user["id"], problem, exam)
            flash("warning" if notice else "success",
                  f"오답 목록에 저장했어요. {notice}" if notice else "오답 목록에 저장하고 복습 일정을 만들었어요.")
            st.rerun()
        return

    today = date.today()
    reviews = db.list_reviews(user["id"], problem["id"])
    if not reviews:
        st.caption("복습 일정이 없습니다.")
    for r in reviews:
        _review_card(user, r, today, show_open=False)


def _render_feedback(user: dict, problem, key_prefix: str) -> None:
    st.subheader("🗳️ 분석 결과 평가")
    previous = db.list_feedback_for_problem(user["id"], problem["id"])
    for fb in previous:
        parts = []
        if fb["rating"]:
            parts.append(f"만족도 {fb['rating']}점")
        if fb["is_report"]:
            status = "처리 완료" if fb["status"] == "resolved" else "검토 대기"
            parts.append(f"오류 신고({fb['category']}) · {status}")
        st.caption(f"{fb['created_at'][:10]} · " + " · ".join(parts))
        if fb["admin_note"]:
            st.info(f"관리자 답변: {fb['admin_note']}")

    with st.form(f"{key_prefix}_feedback_{problem['id']}", clear_on_submit=True):
        rating = st.radio(
            "오답 원인 분석이 정확하고 도움이 되었나요?" if problem["verdict"] == "incorrect"
            else "분석 결과가 정확하고 도움이 되었나요?",
            options=list(RATING_OPTIONS), format_func=lambda v: f"{'★' * v} {RATING_OPTIONS[v]}",
            index=None,
        )
        report = st.checkbox("분석 오류 신고하기")
        category = st.selectbox("오류 유형", REPORT_CATEGORIES)
        message = st.text_area("자세한 내용 (오류 신고 시 필수)", max_chars=1000,
                               placeholder="예: 정답은 3인데 AI가 4라고 판정했어요.")
        if st.form_submit_button("제출"):
            if rating is None and not report:
                st.warning("만족도를 선택하거나 오류 신고를 체크해 주세요.")
            elif report and not message.strip():
                st.warning("오류 신고 시 어떤 부분이 잘못되었는지 적어 주세요.")
            else:
                db.add_feedback(user["id"], problem["id"], rating, report,
                                category if report else None, message.strip() or None)
                flash("success", "소중한 의견 감사합니다. 오류 신고는 관리자가 확인한 뒤 답변을 남겨요." if report
                      else "평가해 주셔서 감사합니다!")
                st.rerun()


# ---------- 오답 노트 · 학습 기록 ----------

def render_notes(user: dict, exam: date | None) -> None:
    problem_id = st.session_state.get("open_problem")
    if problem_id:
        problem = db.get_problem(user["id"], problem_id)
        if st.button("← 목록으로"):
            _clear_open_problem()
            st.rerun()
        if problem is None:
            st.warning("문제를 찾을 수 없습니다. 삭제되었거나 보관 기간이 지났을 수 있어요.")
            return
        st.title("📄 문제 다시 보기")
        render_problem(user, problem, exam, key_prefix="note")
        st.divider()
        with st.popover("🗑️ 이 기록 삭제"):
            st.markdown("사진, 분석 결과, 복습 일정이 모두 삭제되며 복구할 수 없어요.")
            if st.button("삭제", type="primary", key="delete_problem"):
                services.delete_problem(user["id"], problem["id"])
                _clear_open_problem()
                flash("success", "기록을 삭제했어요.")
                st.rerun()
        return

    st.title("📚 오답 노트·학습 기록")
    view = st.radio("보기", ["오답 목록", "전체 학습 기록"], horizontal=True, label_visibility="collapsed")
    problems = db.list_problems(user["id"], saved_only=(view == "오답 목록"))

    f1, f2 = st.columns(2)
    verdicts = f1.multiselect("정오답", ["incorrect", "correct", "undetermined"],
                              format_func=lambda v: {"incorrect": "오답", "correct": "정답", "undetermined": "판단 불가"}[v])
    causes = f2.multiselect("오답 원인", list(CAUSE_LABEL), format_func=CAUSE_LABEL.get)
    if verdicts:
        problems = [p for p in problems if p["verdict"] in verdicts]
    if causes:
        problems = [p for p in problems if set(p["cause_types"].split(",")) & set(causes)]

    if not problems:
        if view == "오답 목록":
            st.info("오답 목록이 비어 있어요. 문제를 분석한 뒤 **오답 목록에 저장**해 보세요.")
        else:
            st.info("조건에 맞는 학습 기록이 없어요.")
        return

    st.caption(f"총 {len(problems)}개")
    for p in problems:
        with st.container(border=True):
            info, action = st.columns([5, 1])
            with info:
                verdict_badge(p["verdict"])
                st.markdown(f"**{p['summary']}**")
                meta = [p["analyzed_at"][:10]]
                if c := cause_text(p["cause_types"]):
                    meta.append(c)
                if p["saved"]:
                    meta.append(f"복습 {p['review_done']}/{p['review_total']} 완료")
                st.caption(" · ".join(meta))
            if action.button("열기", key=f"open_p_{p['id']}", width="stretch"):
                goto(NOTES, p["id"])


# ---------- 시험일 ----------

def render_exam(user: dict, exam: date | None) -> None:
    st.title("📅 시험일 설정")
    st.markdown(
        "문제를 분석한 날을 기준으로 **1일·3일·7일 차**에 복습하도록 일정을 만들어요 (에빙하우스 망각곡선).  \n"
        "시험일 이후로 넘어가는 복습은 **시험 전날**로 앞당기고, 같은 날로 겹치는 회차는 하나로 합쳐요."
    )
    today = date.today()
    if exam:
        st.info(f"현재 시험일: **{exam:%Y년 %m월 %d일}**" + (" (지난 날짜)" if exam < today else ""))

    with st.form("exam_form"):
        new_exam = st.date_input("시험 날짜", value=exam if exam and exam > today else today + timedelta(days=14),
                                 min_value=today + timedelta(days=1), format="YYYY-MM-DD")
        submitted = st.form_submit_button("저장", type="primary")
    if submitted:
        adjusted = services.update_exam_date(user["id"], new_exam)
        msg = f"시험일을 {new_exam:%Y-%m-%d}로 저장하고 미완료 복습 일정을 다시 계산했어요."
        if adjusted:
            msg += f" 문제 {adjusted}개의 복습이 시험 전으로 조정되었어요."
        flash("success", msg)
        st.rerun()

    if exam and st.button("시험일 삭제"):
        services.update_exam_date(user["id"], None)
        flash("success", "시험일을 삭제하고 기본 1·3·7일 일정으로 되돌렸어요.")
        st.rerun()


# ---------- 정책 ----------

def render_policy(user: dict, exam: date | None) -> None:
    st.title("🔒 개인정보·보관 정책")
    render_policy_text()
    st.divider()
    st.subheader("내 학습 기록 전체 삭제")
    st.markdown("업로드한 사진, 분석 결과, 오답 목록, 복습 일정이 모두 삭제되며 **복구할 수 없습니다.**")
    confirm = st.text_input("계속하려면 '전체 삭제'를 입력하세요.")
    if st.button("전체 삭제", type="primary", disabled=confirm.strip() != "전체 삭제"):
        count = services.delete_all_records(user["id"])
        flash("success", f"학습 기록 {count}개를 삭제했어요.")
        st.rerun()
